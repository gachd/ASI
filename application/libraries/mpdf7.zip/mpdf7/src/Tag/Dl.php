<?php

namespace Mpdf\Tag;

class Dl extends BlockTag
{


}
