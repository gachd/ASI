<?php

namespace Mpdf\Tag;

class Sup extends InlineTag
{


}
