<!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css">

<style>

table{    font-family: monospace;
    font-size: 12px;
    }

</style>
<table width="100%" border="0">
  <tbody>
    <tr>
      <td width="17%" rowspan="4"><img src="http://www.stadioitalianodiconcepcion.cl/ASI/assets/images/logo.png" alt="" width="129" height="74"/></td>
      <td width="83%">Insituciones Italianas Di Concepción.</td>
    </tr>
    <tr>
      <td>Camino a Coronel km 13,5 Concepción</td>
    </tr>
    <tr>
      <td>Tel: 41 2 390 003. Correo: circolo@enti-italiani.cl</td>
    </tr>
    <tr>
      <td>http://www.stadioitalianodiconcepcion.cl</td>
    </tr>
  </tbody>
</table>