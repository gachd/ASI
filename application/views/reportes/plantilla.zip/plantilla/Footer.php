


<!-- jQuery -->


   <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
<script>jQuery(document).ready(function($) {
    setTimeout(function() {
        $(".error").fadeOut(1500);
    },3000);
});</script>
   
  </body>
</html>